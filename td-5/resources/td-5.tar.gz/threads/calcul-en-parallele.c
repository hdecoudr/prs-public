#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX  10000000
double resultat[MAX];
int nb_threads;

int 
main(int argc, char *argv[])
{
  nb_threads = atoi(argv[1]);
 

  for(int k=0; k < MAX; k++)
    resultat[k] = acos(cos((double)k)); 
 

  return EXIT_SUCCESS;
}
